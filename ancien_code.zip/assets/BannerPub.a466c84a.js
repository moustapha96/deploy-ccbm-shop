import{c as s,j as e}from"./index.41c86726.js";import{T as i}from"./truck.971f8504.js";/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=s("ShieldCheck",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=s("Trophy",[["path",{d:"M6 9H4.5a2.5 2.5 0 0 1 0-5H6",key:"17hqa7"}],["path",{d:"M18 9h1.5a2.5 2.5 0 0 0 0-5H18",key:"lmptdp"}],["path",{d:"M4 22h16",key:"57wxv0"}],["path",{d:"M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22",key:"1nw9bq"}],["path",{d:"M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22",key:"1np0yb"}],["path",{d:"M18 2H6v7a6 6 0 0 0 12 0V2Z",key:"u46fv3"}]]);function d({className:t,type:r=3}){return e.jsx("div",{className:"container-x mx-auto my-[20px]",children:e.jsxs("div",{"data-aos":"fade-down",className:`best-services w-full flex flex-col space-y-4 \r
        lg:space-y-0 lg:flex-row lg:justify-between \r
        lg:items-center lg:h-[70px] px-6 lg:py-0 py-3 bg-bleu-logo`,children:[e.jsx("div",{className:"item",children:e.jsxs("div",{className:"flex space-x-4 items-center",children:[e.jsx("div",{children:e.jsx("span",{children:e.jsx(i,{color:"white",size:30})})}),e.jsx("div",{children:e.jsx("p",{className:"text-white text-[14px] font-700 tracking-wide uppercase",children:"Livraison gratuite sur Dakar"})})]})}),e.jsx("div",{className:"item",children:e.jsxs("div",{className:"flex space-x-4 items-center",children:[e.jsx("div",{children:e.jsx("span",{children:e.jsx(a,{size:30,color:"white"})})}),e.jsx("div",{children:e.jsx("p",{className:"text-white text-[14px] font-700 tracking-wide uppercase",children:"Paiement en ligne 100% sécurisé"})})]})}),e.jsx("div",{className:"item",children:e.jsxs("div",{className:"flex space-x-4 items-center",children:[e.jsx("div",{children:e.jsx("span",{children:e.jsx(c,{size:30,color:"white"})})}),e.jsx("div",{children:e.jsx("p",{className:"text-white text-[14px] font-700 tracking-wide uppercase",children:"Garantie du produit original"})})]})})]})})}export{d as B};
