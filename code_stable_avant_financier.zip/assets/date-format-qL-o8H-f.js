const e=t=>new Date(t).toLocaleDateString("fr-FR",{day:"2-digit",month:"long",year:"numeric"});export{e as f};
